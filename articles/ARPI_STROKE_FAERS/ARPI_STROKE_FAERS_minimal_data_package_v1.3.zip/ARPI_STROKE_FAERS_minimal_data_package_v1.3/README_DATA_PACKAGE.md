# ARPI Stroke FAERS Minimal Data Package

Status: public data-sharing package, version 1.3. The package is available at https://malt-public.s3.cn-northwest-1.amazonaws.com.cn/ARPI_STROKE_FAERS_minimal_data_package_v1.3.zip.

The derived data and documentation in this package are released under the Creative Commons Attribution 4.0 International licence (CC BY 4.0); see `LICENCE_CC_BY_4.0.md`. The original FDA/AEMS files are not redistributed and remain subject to the terms of their source provider.

## Purpose

This package contains the minimum derived data and metadata needed to inspect the report-level results reported in the manuscript. It is a data-sharing package, not a full computational repository.

The package intentionally excludes the complete analysis code, software environment files, audit logs, rendered figure files, intermediate SQLite databases and raw FDA quarterly ZIP files. The FDA source-file identities, source URLs and hashes are retained in `inputs/raw_zip_manifest_verified.json`.

## Contents

- `inputs/`: ARPI, co-exposure, explicit prostate-cancer indication and researcher-defined stroke-term dictionaries, plus the FDA source-file manifest.
- `outputs/primary/`: the derived report-level analysis file, primary aggregate tables and figure source data.
- `outputs/supplementary/`: machine-readable supplementary tables and sensitivity-analysis source data.
- `metadata/figure_provenance.json`: mapping information for the figure source data.
- `DATA_DICTIONARY_ECRS.md`: field definitions for the report-level analysis file.
- `FILE_MANIFEST_SHA256.csv`: SHA-256 checksums for the package files, excluding the manifest itself.
- `LICENCE_CC_BY_4.0.md`: licence notice for the derived data and documentation.

## Interpretation limits

The analysis unit is a FAERS report, not a patient. The report-level file does not estimate incidence, patient-level comparative risk or causality. The 17-term stroke endpoint is a researcher-defined coding query and is not an official Standardised MedDRA Query or a clinical adjudication.

The report-level file is derived data rather than the original FDA quarterly archive. The original FDA files remain publicly downloadable from the FDA using the URLs and file hashes in the source-file manifest.

## Public access and licence

The version 1.3 ZIP is publicly accessible at the URL in the status line above. The derived report-level data, aggregate tables, dictionaries, provenance metadata and documentation are licensed under CC BY 4.0. The licence does not apply to the FDA/AEMS source files, which are not redistributed here.
