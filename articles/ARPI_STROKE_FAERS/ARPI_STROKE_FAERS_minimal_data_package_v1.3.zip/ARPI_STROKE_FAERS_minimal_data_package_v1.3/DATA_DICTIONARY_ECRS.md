# ECRS report-level analysis data dictionary

The file `outputs/primary/ECRS_report_level_analysis_data.csv` contains one row per final deduplicated FAERS report retained in the primary analysis.

| Field | Meaning |
|---|---|
| `primaryid` | Public FAERS report-version identifier retained after the study's deterministic version rule; not a patient identifier. |
| `drug` | One of the four mutually exclusive target ARPI report groups. |
| `quarter` | Source FAERS calendar quarter. |
| `stroke_primary` | Binary match to at least one of the 17 exact primary reaction labels. |
| `exclusive_subtype` | Descriptive coding category used for the composition figure. |
| `ischaemic` | Binary presence of an ischaemic-coded primary label. |
| `haemorrhagic` | Binary presence of a haemorrhagic-coded primary label. |
| `unspecified` | Binary presence of an unspecified-coded primary label. |
| `tia` | Binary presence of the separately defined transient ischaemic attack label. |

Multiple reaction labels may occur in one report. The file contains no direct personal identifiers, clinical narratives or free-text case descriptions.
