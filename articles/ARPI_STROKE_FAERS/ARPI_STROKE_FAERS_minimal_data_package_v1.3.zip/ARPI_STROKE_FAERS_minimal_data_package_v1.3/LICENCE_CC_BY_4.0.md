# Data and documentation licence

Unless otherwise stated, the derived report-level data, aggregate tables, endpoint and drug dictionaries, provenance metadata, data dictionary, README and other documentation in this package are licensed under the Creative Commons Attribution 4.0 International licence (CC BY 4.0).

You may share and adapt these materials provided that appropriate credit is given, a link to the licence is provided, and changes are indicated.

Licence: https://creativecommons.org/licenses/by/4.0/

The original FDA/AEMS quarterly files are not redistributed in this package. They remain subject to the terms and conditions of their source provider. This licence does not grant rights to those source files or to other third-party content.
